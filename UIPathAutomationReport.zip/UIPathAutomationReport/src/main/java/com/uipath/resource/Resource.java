package com.uipath.resource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.uipath.excelread.ExportToExcelRead;
/**
 * Export to Excel file from UIPATH Studio
 * @author M1046847
 *
 */
public class Resource {
	
	public static WebDriver dr;
	public static EventFiringWebDriver driver;
	public static ExportToExcelRead SuiteData;
	public static ExportToExcelRead TestStepData;
	public static ExportToExcelRead config;
	public static String keyword;
	public static String webElement;
	public static String TestDataField;
	public static String TestData;
	public static String ProceedOnFail;
	public static String TSID;
	public static String Description;
	public static File f;
	public static FileInputStream FI;
	public static String sequen;

	public static void Initialize() throws IOException {

		TestStepData = new ExportToExcelRead(System.getProperty("user.dir") + "//ExportToExcel//mindtree.xlsx");

	}

}
