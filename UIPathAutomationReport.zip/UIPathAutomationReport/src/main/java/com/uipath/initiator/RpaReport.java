package com.uipath.initiator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.uipath.resource.Resource;
import com.uipath.resource.TestUtils;
import com.uipath.utilities.ReportUtil;



/**
 * Main class to generate report
 * @author M1046847
 *
 */
public class RpaReport extends Resource {
	public String path;
	public FileInputStream fis = null;
	public FileOutputStream fileOut = null;
	private static XSSFWorkbook workbook = null;
	private static XSSFSheet sheet = null;
	private static XSSFRow row = null;
	private static XSSFCell cell = null;
	public static final String SEQ_XLSX_FILE_PATH = ".//ExportToExcel//mindtree.xlsx";

	public static void main(String[] args) throws IOException {

		String startTime = TestUtils.now("dd.MMMM.yyyy hh.mm.ss aaa");
		ReportUtil.startTesting(System.getProperty("user.dir") + "//RPA_Report//index.html", startTime, "UIPathHACK",
				"1.0");

		ReportUtil.startSuite("Action1");
		ReportUtil.addKeyword("Navigate to mindtree", "Navigate To", "Pass", null);
		ReportUtil.addKeyword("verify Industries tab", "Check", "Pass",
				System.getProperty("user.dir") + "//Screenshot//387720e1108c3e043fa3a23c30fbfacb.png");
		ReportUtil.addKeyword("verify Services tab", "Check", "Pass",
				System.getProperty("user.dir") + "//Screenshot//d174699405fe2938ceaa79783c6829f5.png");
		ReportUtil.addKeyword("verify Careers tab", "Check", "Pass",
				System.getProperty("user.dir") + "//Screenshot//6dd16fb234ebba89b7feaadd51f4fb6e.png");
		ReportUtil.addKeyword("verify About tab", "Check", "Pass",
				System.getProperty("user.dir") + "//Screenshot//b6aecb94553daa5d724666e33af3d98c.png");
		ReportUtil.addTestCase("Action1", startTime, TestUtils.now("dd.MMMM.yyyy hh.mm.ss aaa"), "Pass");
		ReportUtil.endSuite();
		ReportUtil.updateEndTime(TestUtils.now("dd.MMMM.yyyy hh.mm.ss aaa"));

	}
}
